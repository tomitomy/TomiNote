
Please put the SQLite3 dynamic link library file here (sqlite3.dll in Windows, libsqlite3.so in Linux).

请将 SQLite3 的动态链接库文件放在这里（在 Windows 中为 sqlite3.dll，在 Linux 中为 libsqlite3.so）。



