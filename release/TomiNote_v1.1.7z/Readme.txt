Explanation:

TomiNote is an executable file under Linux.

TomiNote.exe is an executable file under Windows.



说明：

TomiNote 是 Linux 下的可执行文件。

TomiNote.exe 是 Windows 下的可执行文件。



